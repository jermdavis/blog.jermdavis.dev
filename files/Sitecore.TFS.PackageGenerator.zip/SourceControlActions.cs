﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sitecore.TFS.PackageGenerator
{

    [Flags]
    public enum SourceControlActions
    {
        None = 0,
        Add = 1,
        Edit = 2,
        Delete = 4,
        SourceRename = 8
    }

}