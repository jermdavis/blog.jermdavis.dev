﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace Sitecore.TFS.PackageGenerator.Outputs
{
    
    public interface IOutput
    {
        void Initialise(ProjectConfiguration config);
        void Store(XElement data, string filename);
    }

}