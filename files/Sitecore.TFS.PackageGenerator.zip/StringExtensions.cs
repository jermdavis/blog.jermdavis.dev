﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sitecore.TFS.PackageGenerator
{

    public static class StringExtensions
    {
        public static bool CaseInsensitiveContains(this string source, string target)
        {
            return System.Globalization.CultureInfo.CurrentCulture.CompareInfo.IndexOf(source, target, System.Globalization.CompareOptions.IgnoreCase) > -1;
        }
    }

}