﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore.Data;

namespace Testing.Sitemaps
{

    public static class Identifiers
    {
        // Item IDs
        public static readonly ID ConfigItemID = new ID("{D1B5B393-05EA-44F3-95C1-C450922E8AA2}");

        // Template IDs
        public static readonly ID SitemapFileTemplateID = new ID("{C89B8D03-A555-4DEA-8DE0-FFEA734D5A75}");
        public static readonly ID SitemapIndexFileTemplateID = new ID("{DAA619FA-AFA6-4715-B5BA-82B8922251EC}");
        public static readonly ID SitemapItemExtensionsTemplateID = new ID("{52FB59F2-2540-4DF5-B9BA-1463AB17BF3F}");
        public static readonly ID SitemapComponentImageTemplateID = new ID("{DFC4C37F-965B-4868-BB89-AB8592E5A795}");
        public static readonly ID SitemapFieldImageTemplateID = new ID("{9DEA1C4C-CA98-4326-99AA-1097C0FE623F}");

        // Field IDs
        public static readonly ID __UpdatedFieldID = new ID("{D9CF14B1-FA16-4BA6-9288-E8A174D4D522}");
        public static readonly ID SitemapFilenameFieldID = new ID("{BE758AF8-3B5C-4101-AF1B-4602CD09DC0F}");
        public static readonly ID SitemapSourceDatabaseFieldID = new ID("{11457B19-17DE-47B3-8232-FEF07BF0223B}");
        public static readonly ID SitemapRootItemFieldID = new ID("{8285D933-B9EB-4DB5-B5C9-0CC6ED343B26}");
        public static readonly ID SitemapIncludeLanguagesFieldID = new ID("{C53B06DA-ECB8-466B-96C6-CE3DD56D86A9}");
        public static readonly ID SitemapIncludeTemplatesFieldID = new ID("{708D274D-8665-40FC-9734-F26570168041}");

        public static readonly ID SitemapIncludeFieldID = new ID("{374F4F0C-8EED-44FA-A633-C36F70CD454B}");
        public static readonly ID SitemapPriorityFieldID = new ID("{D656FD67-D599-4B71-9F2C-CFAB02C2AA07}");
        public static readonly ID SitemapChangeFrequencyFieldID = new ID("{2D054D4F-60D9-4C99-B77F-DD8F42663FA5}");

        public static readonly ID SitemapImageFieldName_FieldBasedFieldID = new ID("{9175B11D-EB34-46AC-9D7A-668C8BB164BD}");

        public static readonly ID SitemapImageFieldName_ComponentBasedFieldID = new ID("{5D2216A0-2390-45E8-8250-AC63B339962F}");
        public static readonly ID SitemapImageComponentFieldID = new ID("{C999D3C0-D703-46F1-A3E7-EF624D447C5F}");
        public static readonly ID SitemapImageDataSourceTemplateFieldID = new ID("{5E61D607-98F6-4DF2-9421-A872AE86CC67}");

        public static readonly ID SitemapIndexFilenameFieldID = new ID("{DB83067A-07C5-464E-89FF-00C2FFBF9B88}");

        public static readonly ID DescriptionFieldID = new ID("{BA8341A1-FF30-47B8-AE6A-F4947E4113F0}");
        public static readonly ID TitleFieldID = new ID("{3F4B20E9-36E6-4D45-A423-C86567373F82}");
    }

}