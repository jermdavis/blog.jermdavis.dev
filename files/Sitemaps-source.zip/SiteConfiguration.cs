using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore.Data;
using Sitecore.Data.Items;
using Sitecore.Globalization;

namespace Testing.Sitemaps
{

    public class SiteConfiguration
    {
        public string SitemapFilename { get; private set; }
        public string SitemapSourceDatabaseName { get; private set; }
        public Database SitemapSourceDatabase { get; private set; }
        public ID SitemapRootItem { get; private set; }
        public IEnumerable<string> SitemapIncludeLanguages { get; private set; }
        public IEnumerable<ID> SitemapIncludeTemplates { get; private set; }
        public IEnumerable<ImageConfiguration> ImageExtraction { get; private set; }

        private Language getLanguage(string name)
        {
            Language l;

            if (Language.TryParse(name, out l))
            {
                return l;
            }

            return null;
        }

        public SiteConfiguration(Item siteItem)
        {
            SitemapFilename = siteItem.Fields[Identifiers.SitemapFilenameFieldID].Value;

            SitemapSourceDatabaseName = siteItem.Fields[Identifiers.SitemapSourceDatabaseFieldID].Value;

            SitemapSourceDatabase = Sitecore.Configuration.Factory.GetDatabase(SitemapSourceDatabaseName);

            ID rootItem = ID.Null;
            ID.TryParse(siteItem.Fields[Identifiers.SitemapRootItemFieldID].Value, out rootItem);
            SitemapRootItem = rootItem;

            SitemapIncludeLanguages = siteItem.Fields[Identifiers.SitemapIncludeLanguagesFieldID].Value.Split('|')
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .Select(s => ID.Parse(s))
                .Select(i => SitemapSourceDatabase.GetItem(i))
                .Select(l => l.Name);

            SitemapIncludeTemplates = siteItem.Fields[Identifiers.SitemapIncludeTemplatesFieldID].Value.Split('|')
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .Select(s => ID.Parse(s));

            var imageExtraction = siteItem.Axes.SelectItems(string.Format("./*[@@templateid='{0}' or @@templateid='{1}']", Identifiers.SitemapFieldImageTemplateID, Identifiers.SitemapComponentImageTemplateID));
            if (imageExtraction != null && imageExtraction.Length > 0)
            {
                ImageExtraction = imageExtraction
                    .Select(i => new ImageConfiguration(this, i));
            }
            else
            {
                ImageExtraction = new List<ImageConfiguration>();
            }
        }
    }

}