﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sitecore.TFS.PackageGenerator.PipelineComponents
{

    public class RemoveUnwantedItems : IPipelineComponent
    {
        public const string ExtensionsToIgnoreKey = "RemoveUnwantedItems.ExtensionsToIgnore";
        public const string FoldersToIgnoreKey = "RemoveUnwantedItems.FoldersToIgnore";

        private string[] extensions;
        private string[] folders;

        public void Run(PipelineData data)
        {
            if (!data.Configuration.Settings.ContainsKey(ExtensionsToIgnoreKey))
            {
                data.Configuration.ThrowMissingConfigurationException(ExtensionsToIgnoreKey, "A comman separated list of file extensions to ignore when processing. Processed by an 'ends with' query.");
            }
            extensions = data.Configuration.Settings[ExtensionsToIgnoreKey].Split(',');

            if (!data.Configuration.Settings.ContainsKey(FoldersToIgnoreKey))
            {
                data.Configuration.ThrowMissingConfigurationException(FoldersToIgnoreKey, "A comman separted list of folders to ignore. Processed by a 'contains' query.");
            }
            folders = data.Configuration.Settings[FoldersToIgnoreKey].Split(',');

            string[] keys = new string[data.Input.Keys.Count];
            data.Input.Keys.CopyTo(keys, 0);

            foreach (string key in keys)
            {
                if (hasExcludedExtension(key) || containsExcludedFolder(key) || noExtension(key))
                {
                    data.Input.Remove(key);
                    continue;
                }
            }
        }

        private bool hasExcludedExtension(string key)
        {
            foreach (string extension in extensions)
            {
                if (key.EndsWith(extension, StringComparison.InvariantCultureIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }

        private bool containsExcludedFolder(string key)
        {
            foreach (string folder in folders)
            {
                if (key.CaseInsensitiveContains(folder))
                {
                    return true;
                }
            }

            return false;
        }

        private bool noExtension(string key)
        {
            string remainder = key.Substring(key.LastIndexOf("/"));

            if (!remainder.Contains("."))
            {
                return true;
            }

            if (remainder == "/")
            {
                return true;
            }

            return false;
        }
    }

}