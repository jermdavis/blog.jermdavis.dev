﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sitecore.TFS.PackageGenerator.PipelineComponents
{
    
    public class ExtractDeletionsToDeploy : IPipelineComponent
    {
        public void Run(PipelineData data)
        {
            bool deletionsFound = false;

            StringBuilder sb = new StringBuilder();
            sb.Append("The following items require deletion:\r\n");

            foreach (var item in data.Input)
            {
                if ( (item.Value & SourceControlActions.Delete) == SourceControlActions.Delete)
                {
                    deletionsFound = true;
                    sb.Append(item.Key);
                    sb.Append("\r\n");
                }
            }

            if (deletionsFound)
            {
                data.Output.Metadata.ReadMe = sb.ToString();
            }
        }
    }

}