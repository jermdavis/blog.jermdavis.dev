﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sitecore.TFS.PackageGenerator.PipelineComponents
{

    public class ExtractBinariesToDeploy : IPipelineComponent
    {
        public const string ProjectPathMapKey = "ExtractBinariesToDeploy.ProjectPathMap";

        private Dictionary<string, List<string>> extractProjectPathMap(PipelineData data)
        {
            Dictionary<string, List<string>> projectPathMap = new Dictionary<string, List<string>>(StringComparer.CurrentCultureIgnoreCase);
            var projectsCfg = data.Configuration.Settings[ProjectPathMapKey].Split(',');
            foreach (string project in projectsCfg)
            {
                string[] parts = project.Split('|');

                List<string> files = new List<string>();
                for (int i = 1; i < parts.Length; i++)
                {
                    files.Add(parts[i]);
                }

                projectPathMap.Add(parts[0], files);
            }

            return projectPathMap;
        }

        public void Run(PipelineData data)
        {
            var fs = new PackageModel.PackageSourceFiles();
            fs.Name = "Binaries to deploy";

            if (!data.Configuration.Settings.ContainsKey(ProjectPathMapKey))
            {
                data.Configuration.ThrowMissingConfigurationException(ProjectPathMapKey, "A comma separated list of settings. Each one is a pipe separated items. The first part is the project path. All subsequent parts are binaries to add if C# files in the project have been changed.");
            }

            var projectPathMap = extractProjectPathMap(data);
            var projects = projectPathMap.Keys.ToList();

            foreach (var item in data.Input)
            {
                if (item.Key.EndsWith(".cs", StringComparison.CurrentCultureIgnoreCase))
                {
                    foreach (string project in projects.ToArray())
                    {
                        if (item.Key.CaseInsensitiveContains(project))
                        {
                            projects.Remove(project);

                            foreach (string file in projectPathMap[project])
                            {
                                fs.Add(file);
                            }
                        }
                    }

                    if (projects.Count == 0)
                    {
                        break;
                    }
                }
            }

            data.Output.Sources.AddSource(fs);
        }
    }

}