﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Sitecore.TFS.PackageGenerator.Inputs;
using Sitecore.TFS.PackageGenerator.Outputs;
using Sitecore.TFS.PackageGenerator.PipelineComponents;

namespace Sitecore.TFS.PackageGenerator
{

    public class ProjectConfiguration
    {
        public string WorkingFolder { get; private set; }
        public IList<IPipelineComponent> PipelineComponents { get; private set; }
        public IDictionary<string, string> Settings { get; private set; }
        public IInput Input { get; private set; }
        public IOutput Output { get; private set; }
        public ConsoleLog Log { get; private set; }

        public ProjectConfiguration()
        {
            PipelineComponents = new List<IPipelineComponent>();
            Settings = new Dictionary<string, string>(StringComparer.CurrentCultureIgnoreCase);
            Log = new ConsoleLog();
        }

        public void ThrowMissingConfigurationException(string keyName, string description)
        {
            throw new Exception(string.Format("Configuration setting '{0}' was not found: {1}", keyName, description));
        }

        private T createInstance<T>(string type)
        {
            Type t = Type.GetType(type);
            System.Reflection.ConstructorInfo ci = t.GetConstructor(System.Type.EmptyTypes);
            return (T)ci.Invoke(null);
        }

        private void parse(XDocument xml)
        {
            XElement root = xml.Element("configuration");

            string inputType = root.Element("input").Attribute("type").Value;
            Input = createInstance<IInput>(inputType);

            string outputType = root.Element("output").Attribute("type").Value;
            Output = createInstance<IOutput>(outputType);

            WorkingFolder = root.Element("workingFolder").Value;

            foreach (var component in root.Element("pipelineComponents").Elements("component"))
            {
                string type = component.Attribute("type").Value;

                Type t = Type.GetType(type);
                System.Reflection.ConstructorInfo ci = t.GetConstructor(System.Type.EmptyTypes);
                IPipelineComponent cmp = ci.Invoke(null) as IPipelineComponent;

                PipelineComponents.Add(cmp);
            }

            foreach (var item in root.Element("settings").Elements("setting"))
            {
                Settings.Add(item.Attribute("name").Value, item.Attribute("value").Value);
            }
        }

        public static ProjectConfiguration Load(string file)
        {
            ProjectConfiguration pc = new ProjectConfiguration();

            using (var xr = new System.Xml.XmlTextReader(file))
            {
                var xml = XDocument.Load(xr);
                pc.parse(xml);
            }

            return pc;
        }
    }

}