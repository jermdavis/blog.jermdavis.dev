﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace Sitecore.TFS.PackageGenerator.PackageModel
{

    public class PackageSources : IToXml
    {
        private List<IPackageSource> _sources = new List<IPackageSource>();

        public void AddSource(IPackageSource source)
        {
            _sources.Add(source);
        }

        public XElement ToXml()
        {
            XElement xSources = new XElement("Sources");

            foreach (IPackageSource src in _sources)
            {
                xSources.Add(src.ToXml());
            }

            return xSources;
        }
    }

}