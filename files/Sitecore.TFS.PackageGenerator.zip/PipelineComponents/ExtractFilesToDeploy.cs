﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sitecore.TFS.PackageGenerator.PipelineComponents
{

    public class ExtractFilesToDeploy : IPipelineComponent
    {
        public const string WebProjectFolderKey = "ExtractFilesToDeploy.WebProjectFolder";

        public void Run(PipelineData data)
        {
            if (!data.Configuration.Settings.ContainsKey(WebProjectFolderKey))
            {
                data.Configuration.ThrowMissingConfigurationException(WebProjectFolderKey, "This should be the disk path to the web project folder.");
            }
            string webProjectFolder = data.Configuration.Settings[WebProjectFolderKey]; 
            

            var fs = new PackageModel.PackageSourceFiles();
            fs.Name = "Files to deploy";

            foreach (var item in data.Input)
            {
                if (!item.Key.EndsWith(".item", StringComparison.CurrentCultureIgnoreCase) && !item.Key.EndsWith(".cs", StringComparison.CurrentCultureIgnoreCase)  && item.Value.IsNotDelete())
                {
                    fs.Add(item.Key.Replace(webProjectFolder, ""));
                }
            }

            data.Output.Sources.AddSource(fs);
        }
    }

}