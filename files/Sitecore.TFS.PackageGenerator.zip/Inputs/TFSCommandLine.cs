﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;

namespace Sitecore.TFS.PackageGenerator.Inputs
{

    public class TFSCommandLine : IInput
    {
        public const string ToolPathKey = "TFSCommandLine.ToolPath";

        private string _toolPath;
        private string _argumentTemplate = @"history .\ /recursive /format:detailed /noprompt /version:{0}";

        private ProjectConfiguration _config;

        public Action<string> RawTFSDataCallback = null;

        public void Initialise(ProjectConfiguration config)
        {
            _config = config;

            if (!config.Settings.ContainsKey(ToolPathKey))
            {
                config.ThrowMissingConfigurationException(ToolPathKey, "The fully qualified disk path for tf.exe");
            }
            _toolPath = config.Settings[ToolPathKey];
        }

        public IDictionary<string, SourceControlActions> ProcessWorkItems(string workingFolder, int firstChange, int lastChange)
        {
            var output = runTool(workingFolder, firstChange, lastChange);
            if (RawTFSDataCallback != null)
            {
                RawTFSDataCallback(output);
            }

            var filteredOutput = filterOutput(output);

            return parse(filteredOutput);
        }

        private string runTool(string workingFolder, int firstChange, int lastChange)
        {
            string output;

            using (Process p = new Process())
            {
                p.StartInfo.UseShellExecute = false;
                p.StartInfo.RedirectStandardOutput = true;
                p.StartInfo.FileName = _toolPath;
                p.StartInfo.Arguments = string.Format(_argumentTemplate, formatVersionString(firstChange, lastChange));
                p.StartInfo.WorkingDirectory = workingFolder;
                p.StartInfo.CreateNoWindow = false;

                p.Start();
                output = p.StandardOutput.ReadToEnd();
                p.WaitForExit();
            }

            return output;
        }

        private string formatVersionString(int firstChange, int lastChange)
        {
            string first = "C" + firstChange.ToString();

            string last = string.Empty;
            if (lastChange != -1)
            {
                last = "C" + lastChange.ToString();
            }

            return first + "~" + last;
        }

        private IEnumerable<string> filterOutput(string output)
        {
            var items = output
                .Split('\n')
                .Select(i => i.Trim())
                .Where(i =>
                    i.StartsWith("edit", StringComparison.InvariantCultureIgnoreCase) ||
                    i.StartsWith("add", StringComparison.InvariantCultureIgnoreCase) ||
                    i.StartsWith("delete", StringComparison.InvariantCultureIgnoreCase));

            return items;
        }

        private IDictionary<string, SourceControlActions> parse(IEnumerable<string> input)
        {
            char[] splitter = {'$'};

            Dictionary<string, SourceControlActions> results = new Dictionary<string, SourceControlActions>();

            var items = input
                .Select(i => i.Split(splitter, StringSplitOptions.RemoveEmptyEntries))
                .Where(i => i.Length > 1)
                .OrderBy(i => i[1]);

            foreach (var item in items)
            {
                string path = item[1];

                if (path.Contains(';'))
                {
                    // Deletion operations include this - remove it?
                    path = path.Substring(0, path.IndexOf(';'));
                }

                SourceControlActions action = parseActions(item[0].Trim());

                if (results.ContainsKey(path))
                {
                    results[path] = results[path] | action;
                }
                else
                {
                    results.Add(path, action);
                }
            }

            return results;
        }

        private SourceControlActions parseActions(string actions)
        {
            SourceControlActions sca = SourceControlActions.None;

            foreach (string action in actions.Split(','))
            {
                string a = action.Trim().Replace(" ", "");

                sca = sca | (SourceControlActions)Enum.Parse(typeof(SourceControlActions), a, true);
            }

            return sca;
        }
    }

}