﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore.Data.Items;

namespace Testing.Sitemaps
{

    public class ImageConfiguration
    {
        public bool IsFieldImage { get; private set; }
        public string ImageFieldName { get; private set; }
        public string ImageComponent { get; private set; }

        public ImageConfiguration(SiteConfiguration sc, Item img)
        {
            if (img.TemplateID == Identifiers.SitemapComponentImageTemplateID)
            {
                IsFieldImage = false;

                ImageFieldName = img.Fields[Identifiers.SitemapImageFieldName_ComponentBasedFieldID].Value;

                string cmpID = img.Fields[Identifiers.SitemapImageComponentFieldID].Value;
                if (!string.IsNullOrWhiteSpace(cmpID))
                {
                    ImageComponent = cmpID.ToUpperInvariant();
                }
            }
            if (img.TemplateID == Identifiers.SitemapFieldImageTemplateID)
            {
                IsFieldImage = true;

                ImageFieldName = img.Fields[Identifiers.SitemapImageFieldName_FieldBasedFieldID].Value;
            }
        }
    }

}