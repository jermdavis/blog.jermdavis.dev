﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sitecore.TFS.PackageGenerator.PipelineComponents
{
    
    public class SetPackageMetadata : IPipelineComponent
    {
        public const string PackageNameKey = "SetPackageMetadata.PackageName";

        public void Run(PipelineData data)
        {
            if (!data.Configuration.Settings.ContainsKey(PackageNameKey))
            {
                data.Configuration.ThrowMissingConfigurationException(PackageNameKey, "This should be the name to set for the package");
            }

            data.Output.Metadata.Name = data.Configuration.Settings[PackageNameKey];
            data.Output.Metadata.Author = System.Environment.UserDomainName + "\\" + System.Environment.UserName;
        }
    }

}