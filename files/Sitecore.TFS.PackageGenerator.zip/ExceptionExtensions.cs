﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sitecore.TFS.PackageGenerator
{
  
    public static class ExceptionExtensions
    {
        public static void Format(this Exception ex, ConsoleLog log)
        {
            var current = ex;
            while (current != null)
            {
                log.WriteLine(ex.Message);
                log.WriteLine(ex.StackTrace);

                current = current.InnerException;
            }
        }
    }

}