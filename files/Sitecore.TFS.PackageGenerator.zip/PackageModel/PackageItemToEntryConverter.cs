﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace Sitecore.TFS.PackageGenerator.PackageModel
{

    public class PackageItemToEntryConverter : IToXml
    {
        public XElement ToXml()
        {
            return new XElement("Converter",
                    new XElement("ItemToEntryConverter",
                            new XElement("Options",
                                    new XElement("BehaviourOptions",
                                            new XElement("ItemMode", "Undefined"),
                                            new XElement("ItemMergeMode", "Undefined")
                                        )
                                )
                        )
                );
        }
    }

}