﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace Sitecore.TFS.PackageGenerator.PackageModel
{

    public class PackageConverter : IToXml
    {
        public XElement ToXml()
        {
            return new XElement("Converter", 
                    new XElement("TrivialConverter", 
                            new XElement("Transforms")
                        )
                );
        }
    }

}