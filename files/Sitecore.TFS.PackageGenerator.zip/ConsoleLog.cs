﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sitecore.TFS.PackageGenerator
{

    public class ConsoleLog
    {
        public void Start()
        {
            WriteWithUnderline("Sitecore.TFS.PackageGenerator");
            WriteLine();
        }

        public void Finish()
        {
            WriteLine("Done.");
        }

        public void WriteWithUnderline(string message)
        {
            Console.WriteLine(message);
            Console.WriteLine(new string('-', message.Length));
        }

        public void WriteLine(string message)
        {
            Console.WriteLine(message);
        }

        public void WriteLine()
        {
            Console.WriteLine();
        }
    }

}