﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Sitecore.TFS.PackageGenerator.PackageModel;
using Sitecore.TFS.PackageGenerator.PipelineComponents;

namespace Sitecore.TFS.PackageGenerator
{

    public class ProcessingPipeline
    {
        private ProjectConfiguration _config;

        public ProcessingPipeline(ProjectConfiguration config)
        {
            _config = config;
        }

        public PackageProject Run(IDictionary<string, SourceControlActions> input)
        {
            PipelineData pd = new PipelineData();
            pd.Configuration = _config;
            pd.Input = input;
            pd.Output = new PackageProject();

            foreach (IPipelineComponent cmp in _config.PipelineComponents)
            {
                cmp.Run(pd);
            }

            return pd.Output;
        }
    }

}