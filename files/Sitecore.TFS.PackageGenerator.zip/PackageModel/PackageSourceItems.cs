﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace Sitecore.TFS.PackageGenerator.PackageModel
{

    public class PackageSourceItems : IPackageSource
    {
        private List<string> _entries = new List<string>();

        public string Name { get; set; }
        public PackageItemToEntryConverter Converter { get; private set; }

        public PackageSourceItems()
        {
            Converter = new PackageItemToEntryConverter();
        }

        public void Add(string entry)
        {
            _entries.Add(entry);
        }

        public XElement ToXml()
        {
            XElement xItems = new XElement("xitems");

            XElement xEntries = new XElement("Entries");
            foreach (string entry in _entries)
            {
                xEntries.Add(new XElement("x-item", entry));
            }
            xItems.Add(xEntries);

            xItems.Add(new XElement("SkipVersions", false));

            xItems.Add(Converter.ToXml());

            xItems.Add(new XElement("Include"));
            xItems.Add(new XElement("Exclude"));

            xItems.Add(new XElement("Name", Name));

            return xItems;
        }
    }

}