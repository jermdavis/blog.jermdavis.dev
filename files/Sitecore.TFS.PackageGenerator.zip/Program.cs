﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommandLine;
using Sitecore.TFS.PackageGenerator.Inputs;

namespace Sitecore.TFS.PackageGenerator
{

    class Program
    {
        static int Main(string[] args)
        {
            ConsoleLog log = new ConsoleLog();

            log.Start();

            CommandLineParameters cmdParams = new CommandLineParameters();
            if (CommandLine.Parser.ParseArgumentsWithUsage(args, cmdParams))
            {
                ProjectConfiguration config = ProjectConfiguration.Load(cmdParams.ConfigFile);

                config.Input.Initialise(config);
                var data = config.Input.ProcessWorkItems(config.WorkingFolder, cmdParams.StartChangeSet, cmdParams.EndChangeSet);

                ProcessingPipeline pp = new ProcessingPipeline(config);
                var packageData = pp.Run(data);

                var xml = packageData.ToXml();

                config.Output.Initialise(config);
                config.Output.Store(xml, cmdParams.PackageFileName);
            }

            log.Finish();

#if DEBUG
            Console.ReadLine();
#endif

            return 0;
        }
    }

}