﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sitecore.TFS.PackageGenerator.PipelineComponents
{

    public interface IPipelineComponent
    {
        void Run(PipelineData data);
    }

}
