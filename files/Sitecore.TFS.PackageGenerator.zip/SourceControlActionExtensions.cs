﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sitecore.TFS.PackageGenerator
{

    public static class SourceControlActionExtensions
    {
        private const SourceControlActions deleteOrRename = SourceControlActions.Delete | SourceControlActions.SourceRename;

        public static bool IsNotDelete(this SourceControlActions action)
        {
            if (action == SourceControlActions.None || (action & deleteOrRename) > 0)
            {
                return false;
            }

            return true;
        }
    }

}