﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using CommandLine;

namespace Sitecore.TFS.PackageGenerator
{

    public class CommandLineParameters
    {
        [Argument(ArgumentType.Required | ArgumentType.AtMostOnce, HelpText="The xml configuration file", ShortName = "c", LongName = "config")]
        public string ConfigFile;

        [Argument(ArgumentType.Required | ArgumentType.AtMostOnce, HelpText = "Starting changeset number", ShortName = "s", LongName = "start")]
        public int StartChangeSet;

        [Argument(ArgumentType.AtMostOnce, HelpText = "Ending changeset number", ShortName = "e", LongName = "end", DefaultValue = -1)]
        public int EndChangeSet;

        [Argument(ArgumentType.AtMostOnce, HelpText = "The file name for the generated package", ShortName = "p", LongName = "package", DefaultValue = "GeneratedPackage.xml")]
        public string PackageFileName;
    }

}