﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore.Data.Items;

namespace Testing.Sitemaps
{

    public class SiteIndexConfiguration
    {
        public string SitemapIndexFilename { get; private set; }
        public IEnumerable<Item> SiteConfigurations { get; private set; }

        public SiteIndexConfiguration(Item cfg)
        {
            SitemapIndexFilename = cfg.Fields[Identifiers.SitemapIndexFilenameFieldID].Value;

            var siteConfigs = cfg.Axes.SelectItems(string.Format("./*[@@templateid='{0}']", Identifiers.SitemapFileTemplateID));
            if (siteConfigs != null && siteConfigs.Length > 0)
            {
                SiteConfigurations = siteConfigs;
            }
            else
            {
                SiteConfigurations = new List<Item>();
            }
        }
    }

}