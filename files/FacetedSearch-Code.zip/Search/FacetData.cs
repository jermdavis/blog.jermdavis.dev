﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;

namespace SCTUG.SearchExample.Search
{

    public class FacetData
    {
        public string Name { get; private set; }
        public IEnumerable<ListItem> Values { get; private set; }

        public FacetData(string name, IEnumerable<ListItem> values)
        {
            Name = name;
            Values = values;
        }
    }

}