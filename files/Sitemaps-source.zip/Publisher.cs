using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;
using Sitecore.Data;
using Sitecore.Data.Fields;
using Sitecore.Data.Items;
using Sitecore.Globalization;
using Sitecore.Layouts;

namespace Testing.Sitemaps
{

    public class Publisher
    {
        public void Publish(object sender, EventArgs args)
        {
            Database master = Sitecore.Configuration.Factory.GetDatabase("master");
            Item configRoot = master.GetItem(Identifiers.ConfigItemID);

            string query = string.Format("child::*[@@templateid='{0}' or @@templateid='{1}']", Identifiers.SitemapFileTemplateID, Identifiers.SitemapIndexFileTemplateID);

            foreach (Item siteConfig in configRoot.Axes.SelectItems(query))
            {
                if (siteConfig.TemplateID == Identifiers.SitemapIndexFileTemplateID)
                {
                    publishSiteIndex(siteConfig);
                }

                if (siteConfig.TemplateID == Identifiers.SitemapFileTemplateID)
                {
                    publishSite(siteConfig);
                }
            }
        }

        private void publishSiteIndex(Item siteIndexConfig)
        {
            SiteIndexConfiguration sc = new SiteIndexConfiguration(siteIndexConfig);

            SitemapIndex si = new SitemapIndex();

            var uo = new Sitecore.Links.UrlOptions()
            {
                AlwaysIncludeServerUrl = true,
                LanguageEmbedding = Sitecore.Links.LanguageEmbedding.AsNeeded,
                ShortenUrls = true
            };

            foreach (Item s in sc.SiteConfigurations)
            {
                SiteConfiguration cfg = publishSite(s);

                Item rt = cfg.SitemapSourceDatabase.GetItem(cfg.SitemapRootItem);
                string rootUrl = Sitecore.Links.LinkManager.GetItemUrl(rt, uo);
                Uri rootUri = new Uri(rootUrl, UriKind.Absolute);

                Uri fileUri = new Uri(rootUri, "/" + cfg.SitemapFilename);

                si.Add(new SitemapIndexItem() { 
                    Location = fileUri.ToString(),
                    LastModified = DateTime.Now
                });
            }

            string filename = System.Web.Hosting.HostingEnvironment.MapPath("/" + sc.SitemapIndexFilename);
            saveXmlToFile(filename, si.Serialise());
        }

        private SiteConfiguration publishSite(Item siteConfig)
        {
            SiteConfiguration sc = new SiteConfiguration(siteConfig);

            SitemapUrlSet sitemap = processSite(sc);

            if (sitemap != null)
            {
                string filename = System.Web.Hosting.HostingEnvironment.MapPath("/" + sc.SitemapFilename);
                saveXmlToFile(filename, sitemap.Serialise());
            }

            return sc;
        }

        private SitemapUrlSet processSite(SiteConfiguration sc)
        {
            Item rootItem = sc.SitemapSourceDatabase.GetItem(sc.SitemapRootItem);
            SitemapUrlSet sitemap = new SitemapUrlSet();

            process(sc, sitemap, rootItem);
            
            return sitemap;
        }

        private void process(SiteConfiguration sc, SitemapUrlSet urls, Item item)
        {
            IEnumerable<SitemapUrl> u = buildSitemapUrl(sc, item);
            if (u != null && u.Count() > 0)
            {
                urls.AddRange(u);
            }

            foreach (Item child in item.Children)
            {
                process(sc, urls, child);
            }
        }

        private IEnumerable<SitemapUrl> buildSitemapUrl(SiteConfiguration sc, Item item)
        {
            if(sc.SitemapIncludeTemplates.Count() > 0 && !sc.SitemapIncludeTemplates.Contains(item.TemplateID))
            {
                return null;
            }

            if (item.Fields.Contains(Identifiers.SitemapIncludeFieldID))
            {
                CheckboxField cf = (CheckboxField)item.Fields[Identifiers.SitemapIncludeFieldID];
                if(!cf.Checked)
                {
                    return null;
                }
            }

            List<SitemapUrl> urls = new List<SitemapUrl>();
            foreach (Language l in item.Languages)
            {
                if (sc.SitemapIncludeLanguages.Contains(l.Name))
                {
                    Item i = sc.SitemapSourceDatabase.GetItem(item.ID, l);
                    if (i.Versions.Count > 0)
                    {
                        SitemapUrl u = processLanguage(sc, i, l);
                        if (u != null)
                        {
                            urls.Add(u);
                        }
                    }
                }
            }
            return urls;
        }

        private SitemapImage makeImg(ImageConfiguration icfg, Item item)
        {
            var mo = new Sitecore.Resources.Media.MediaUrlOptions()
            {
                AlwaysIncludeServerUrl = true,
                AbsolutePath = true
            };

            ImageField img = (ImageField)item.Fields[icfg.ImageFieldName];
            if (img != null && !string.IsNullOrWhiteSpace(img.Value))
            {
                var si = new SitemapImage();
                si.Location = Sitecore.Resources.Media.MediaManager.GetMediaUrl(img.MediaItem, mo);
                    
                string caption = img.MediaItem.Fields[Identifiers.DescriptionFieldID].Value;
                if (!string.IsNullOrWhiteSpace(caption))
                {
                    si.Caption = caption;
                }

                string title = img.MediaItem.Fields[Identifiers.TitleFieldID].Value;
                if (!string.IsNullOrWhiteSpace(title))
                {
                    si.Title = title;
                }

                return si;
            }

            return null;
        }

        private IEnumerable<SitemapImage> processImages(SiteConfiguration sc, Item item, Language l)
        {
            List<SitemapImage> imgs = new List<SitemapImage>();

            foreach (ImageConfiguration icfg in sc.ImageExtraction)
            {
                if (icfg.IsFieldImage)
                {
                    SitemapImage img = makeImg(icfg, item);
                    if (img != null)
                    {
                        imgs.Add(img);
                    }
                }
                else
                {
                    string xml = LayoutField.GetFieldValue(item.Fields["__Renderings"]);
                    LayoutDefinition ld = LayoutDefinition.Parse(xml);

                    DeviceDefinition deviceDef = ld.GetDevice("{FE5D7FDF-89C0-4D99-9AA3-B5FBD009C9F3}");

                    foreach(RenderingDefinition renderingDef in deviceDef.GetRenderings(icfg.ImageComponent))
                    {
                        Item itm = sc.SitemapSourceDatabase.GetItem(renderingDef.Datasource);
                        if (itm != null)
                        {
                            SitemapImage img = makeImg(icfg, itm);
                            if (img != null)
                            {
                                imgs.Add(img);
                            }
                        }
                    }                    
                }
            }

            return imgs;
        }

        private SitemapUrl processLanguage(SiteConfiguration sc, Item item, Language l)
        {
            SitemapUrl url = new SitemapUrl();

            var uo = new Sitecore.Links.UrlOptions(){
                AlwaysIncludeServerUrl = true,
                LanguageEmbedding = Sitecore.Links.LanguageEmbedding.AsNeeded,
                ShortenUrls = true,
                Language = l
            };

            url.Location = Sitecore.Links.LinkManager.GetItemUrl(item, uo);

            url.AddRange(processImages(sc, item, l));

            DateField df = (DateField)item.Fields[Identifiers.__UpdatedFieldID];
            url.LastModified = df.DateTime;

            if (item.Fields.Contains(Identifiers.SitemapPriorityFieldID))
            {
                float f;
                if(float.TryParse(item.Fields[Identifiers.SitemapPriorityFieldID].Value, out f))
                {
                    url.Priority = f;
                }
            }

            if (item.Fields.Contains(Identifiers.SitemapChangeFrequencyFieldID))
            {
                ChangeFrequency cf;
                if (Enum.TryParse<ChangeFrequency>(item.Fields[Identifiers.SitemapChangeFrequencyFieldID].Value, true, out cf))
                {
                    url.ChangeFrequency = cf;
                }
            }

            return url;
        }

        private void saveXmlToFile(string filename, XElement data)
        {
            using (System.Xml.XmlTextWriter xw = new System.Xml.XmlTextWriter(filename, System.Text.Encoding.UTF8))
            {
                data.WriteTo(xw);
            }
        }
    }

}