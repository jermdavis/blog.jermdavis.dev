﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sitecore.TFS.PackageGenerator.PipelineComponents
{

    public class RenameFiles : IPipelineComponent
    {
        public const string ExtensionsKey = "RenameFiles.Extensions";

        public void Run(PipelineData data)
        {
            if(!data.Configuration.Settings.ContainsKey(ExtensionsKey))
            {
                data.Configuration.ThrowMissingConfigurationException(ExtensionsKey, "A list of renames to perform. Separate entries with commas Separate source and target names with a pipe.");
            }
            Dictionary<string, string> renames = new Dictionary<string, string>(StringComparer.CurrentCultureIgnoreCase);
            var extensions = data.Configuration.Settings[ExtensionsKey].Split(',');
            foreach (string extension in extensions)
            {
                var parts = extension.Split('|');
                renames.Add(parts[0].Trim(), parts[1].Trim());
            }

            string[] files = new string[data.Input.Keys.Count];
            data.Input.Keys.CopyTo(files, 0);

            foreach (string file in files)
            {
                foreach (var rename in renames)
                {
                    if (file.EndsWith(rename.Key, StringComparison.CurrentCultureIgnoreCase))
                    {
                        SourceControlActions actions = data.Input[file];
                        data.Input.Remove(file);

                        string newKey = file.Substring(0, file.LastIndexOf('.')) + rename.Value;

                        data.Input.Add(newKey, actions);

                        break;
                    }
                }
            }
        }
    }

}