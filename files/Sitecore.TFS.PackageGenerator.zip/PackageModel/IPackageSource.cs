﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sitecore.TFS.PackageGenerator.PackageModel
{

    public interface IPackageSource : IToXml
    {
        string Name { get; set; }
        void Add(string entry);
    }

}