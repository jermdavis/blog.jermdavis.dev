﻿using Microsoft.Xaml.Behaviors;
using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Imaging;

namespace BlogPasteExample
{

    public class PasteBehavior : Behavior<TextBox>
    {
        protected override void OnAttached()
        {
            base.OnAttached();

            CommandManager.AddPreviewExecutedHandler(AssociatedObject, onPreviewExecuted);
            CommandManager.AddPreviewCanExecuteHandler(AssociatedObject, onPreviewCanExecute);
        }

        private void onPreviewCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            if (e.Command == ApplicationCommands.Paste)
            {
                e.CanExecute = Clipboard.ContainsImage();
                e.Handled = Clipboard.ContainsImage();
            }
        }

        private void onPreviewExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            if (e.Command == ApplicationCommands.Paste)
            {
                if (Clipboard.ContainsImage())
                {
                    // work out a filename
                    // save the image data to disk
                    // work out the web url to use in the link

                    var markup = $"![Alt text here](/path-to-file/goes-here.png)";

                    AssociatedObject.Text = AssociatedObject.Text.Insert(start, markup);

                    e.Handled = true;
                }
            }
        }

        protected override void OnDetaching()
        {
            base.OnDetaching();
            CommandManager.RemovePreviewExecutedHandler(AssociatedObject, onPreviewExecuted);
            CommandManager.RemovePreviewCanExecuteHandler(AssociatedObject, onPreviewCanExecute);
        }
    }

}