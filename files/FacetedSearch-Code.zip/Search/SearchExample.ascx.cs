﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Lucene.Net.Index;
using Lucene.Net.Search;
using Sitecore.Data;
using Sitecore.Data.Items;
using Sitecore.Search;
using Sitecore.Web.UI.WebControls;

namespace SCTUG.SearchExample.Search
{

    public partial class SearchExample : System.Web.UI.UserControl
    {
        private readonly Guid _template = new Guid("{C5537201-AF56-473B-A614-E5DA9FB5079E}");

        protected void Page_Load(object sender, EventArgs e)
        {
            string[] facets = loadConfig();

            BooleanQuery query = buildQuery(facets);

            qry.Text = query.ToString();

            SearchResultCollection results = runQuery(query);

            IEnumerable<FacetData> facetData = buildFilterData(facets, results);

            filterRepeater.DataSource = facetData;
            filterRepeater.ItemDataBound += filterRepeater_ItemDataBound;
            filterRepeater.DataBind();

            // paginate

            resultRepeater.DataSource = results;
            resultRepeater.ItemDataBound += resultRepeater_ItemDataBound;
            resultRepeater.DataBind();
        }

        #region -- Load config --

        private string[] loadConfig()
        {
            string cfgItem = (this.Parent as Sublayout).DataSource;
            Item cfg = Sitecore.Context.Database.GetItem(cfgItem);

            string facets = cfg.Fields["Facets"].Value;

            string[] config = null;

            if (!string.IsNullOrEmpty(facets))
            {
                config = facets.Split('|')
                    .Select(id => Sitecore.Context.Database.GetItem(id))
                    .Select(itm => itm.Fields["SearchIndexField"].Value)
                    .Select(f => f.ToLowerInvariant())
                    .ToArray();
            }

            return config;
        }

        #endregion

        #region -- Build query --

        private BooleanQuery buildQuery(string[] facets)
        {
            BooleanQuery query = new BooleanQuery();

            query.Add(new TermQuery(new Term("_template", ShortID.Encode(_template).ToLowerInvariant())), BooleanClause.Occur.MUST);

            foreach (string facet in facets)
            {
                string key = Request.Form.AllKeys.Where(k => k.EndsWith("$" + facet)).FirstOrDefault();
                if (!string.IsNullOrWhiteSpace(key))
                {
                    string value = Request.Form[key];
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        query.Add(new TermQuery(new Term(facet, value)), BooleanClause.Occur.MUST);
                    }
                }
            }

            return query;
        }

        #endregion

        #region -- Run query --

        private SearchResultCollection runQuery(BooleanQuery query)
        {
            Index index = Sitecore.Search.SearchManager.GetIndex("demo");

            using (IndexSearchContext isc = index.CreateSearchContext())
            {
                SearchHits hits = isc.Search(query, 10000);
                return hits.FetchResults(0, 10000);
            }
        }

        #endregion

        #region -- Build facet data --

        private IEnumerable<FacetData> buildFilterData(string[] facets, SearchResultCollection results)
        {
            List<FacetData> filters = new List<FacetData>();

            foreach (string facet in facets)
            {
                var data = results
                            .Select(r => r.Document.GetValues(facet))
                            .Where(v => v != null && v.Length > 0)
                            .SelectMany(v => v)
                            .Distinct()
                            .Select(v => Sitecore.Context.Database.GetItem(ShortID.Parse(v).ToID()))
                            .Select(v => new ListItem(v.DisplayName, ShortID.Encode(v.ID).ToLowerInvariant()))
                            .OrderBy(i => i.Text);

                FacetData t = new FacetData(facet, data);

                filters.Add(t);
            }

            return filters;
        }

        #endregion

        #region -- Render facet data --

        private void filterRepeater_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                FacetData data = e.Item.DataItem as FacetData;

                DropDownList ddl = e.Item.FindControl("filter") as DropDownList;
                ddl.ID = data.Name;

                var vals = new List<ListItem>();
                vals.Add(new ListItem("-- All " + data.Name + " --", string.Empty));
                vals.AddRange(data.Values);

                ddl.DataSource = vals;
                ddl.DataTextField = "Text";
                ddl.DataValueField = "Value";
                ddl.DataBind();
            }
        }

        #endregion

        #region -- Render results --

        private void resultRepeater_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                SearchResult sr = e.Item.DataItem as SearchResult;

                Item itm = sr.GetObject<Item>();

                var image = e.Item.FindControl("image") as Sitecore.Web.UI.WebControls.Image;
                var title = e.Item.FindControl("title") as Sitecore.Web.UI.WebControls.Text;
                var description = e.Item.FindControl("description") as Sitecore.Web.UI.WebControls.Text;

                image.Item = itm;
                title.Item = itm;
                description.Item = itm;
            }
        }

        #endregion
    }

}