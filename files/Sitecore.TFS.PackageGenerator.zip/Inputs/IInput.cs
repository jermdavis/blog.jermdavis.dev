﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sitecore.TFS.PackageGenerator.Inputs
{
    
    public interface IInput
    {
        void Initialise(ProjectConfiguration config);
        IDictionary<string, SourceControlActions> ProcessWorkItems(string workingFolder, int firstChange, int lastChange);
    }

}