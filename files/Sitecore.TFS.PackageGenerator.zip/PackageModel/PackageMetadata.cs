﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace Sitecore.TFS.PackageGenerator.PackageModel
{

    public class PackageMetadata : IToXml
    {
        public string Name { get; set; }
        public string Author { get; set; }
        public string Version { get; set; }
        public string Revision { get; set; }
        public string License { get; set; }
        public string Comment { get; set; }
        public string Attributes { get; set; }
        public string ReadMe { get; set; }
        public string Publisher { get; set; }
        public string PostStep { get; set; }
        public string PackageID { get; set; }

        public XElement ToXml()
        {
            XElement xInnerMetadata = new XElement("metadata");
            XElement xOuterMetadata = new XElement("Metadata", xInnerMetadata);

            xInnerMetadata.Add(new XElement("PackageName", Name));
            xInnerMetadata.Add(new XElement("Author", Author));
            xInnerMetadata.Add(new XElement("Version", Version));
            xInnerMetadata.Add(new XElement("Revision", Revision));
            xInnerMetadata.Add(new XElement("License", License));
            xInnerMetadata.Add(new XElement("Comment", Comment));
            xInnerMetadata.Add(new XElement("Attributes", Attributes));
            xInnerMetadata.Add(new XElement("ReadMe", ReadMe));
            xInnerMetadata.Add(new XElement("Publisher", Publisher));
            xInnerMetadata.Add(new XElement("PostStep", PostStep));
            xInnerMetadata.Add(new XElement("PackageID", PackageID));

            return xOuterMetadata;
        }
    }

}