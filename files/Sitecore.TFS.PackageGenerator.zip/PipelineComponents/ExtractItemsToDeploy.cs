﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Sitecore.TFS.PackageGenerator.PipelineComponents
{

    public class ExtractItemsToDeploy : IPipelineComponent
    {
        private ProjectConfiguration cfg;

        public void Run(PipelineData data)
        {
            cfg = data.Configuration;

            var pi = new PackageModel.PackageSourceItems();
            pi.Name = "Items to deploy";

            foreach (var item in data.Input)
            {
                if (item.Key.EndsWith(".item", StringComparison.CurrentCultureIgnoreCase) && item.Value.IsNotDelete())
                {
                    try
                    {
                        pi.Add(formatItemIdentifer(item.Key));
                    }
                    catch (FileNotFoundException)
                    {
                        cfg.Log.WriteLine("Serialised Item not found for '" + item.Key + "' - Cannot add to package.");
                    }
                    
                }
            }

            data.Output.Sources.AddSource(pi);
        }

        private string formatItemIdentifer(string key)
        {
            string identifier;

            using (var tr = File.OpenText(key))
            {
                var data = parseFile(tr);

                string db = data["database"];
                string id = data["id"];
                string path = data["path"];

                identifier = string.Format("/{0}{1}/{2}/invariant/0", db, path, id);
            }

            return identifier;
        }

        private IDictionary<string, string> parseFile(StreamReader sr)
        {
            Dictionary<string, string> data = new Dictionary<string, string>(StringComparer.CurrentCultureIgnoreCase);
            bool done = false;

            string text = sr.ReadToEnd();
            sr.BaseStream.Seek(0, SeekOrigin.Begin);

            while (!done)
            {
                string line = sr.ReadLine();

                if(string.IsNullOrWhiteSpace(line))
                {
                    continue;
                }

                if (line.StartsWith("----"))
                {
                    string region = line.Replace("----", "");

                    if (StringComparer.CurrentCultureIgnoreCase.Compare(region,"item") != 0)
                    {
                        done = true;
                    }
                }
                else
                {
                    string[] parts = line.Split(':');
                    data.Add(parts[0].Trim(), parts[1].Trim());
                }
            }

            return data;
        }
    }

}