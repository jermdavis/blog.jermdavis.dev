﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace Testing.Sitemaps
{

    public class SitemapIndex
    {
        private List<SitemapIndexItem> _items = new List<SitemapIndexItem>();

        public IEnumerable<SitemapIndexItem> IndexItems { get { return _items; } }

        public static readonly XNamespace Namespace = "http://www.sitemaps.org/schemas/sitemap/0.9";

        public void Add(SitemapIndexItem itm)
        {
            _items.Add(itm);
        }

        public XElement Serialise()
        {
            XElement root = new XElement("sitemapindex");
            root.Add(new XAttribute("xmlns", Namespace));

            foreach (SitemapIndexItem i in _items)
            {
                root.Add(i.Serialise());
            }

            return root;
        }
    }

    public class SitemapIndexItem
    {
        public string Location { get; set; }
        public DateTime LastModified { get; set; }

        public XElement Serialise()
        {
            XElement root = new XElement("sitemap");

            root.Add(new XElement("loc", Location));
            root.Add(new XElement("lastmod", LastModified.ToString("yyyy-MM-dd")));

            return root;
        }
    }

    public class SitemapUrlSet
    {
        private List<SitemapUrl> _urls = new List<SitemapUrl>();

        public IEnumerable<SitemapUrl> SitemapUrls { get { return _urls; } }

        public void Add(SitemapUrl url)
        {
            _urls.Add(url);
        }

        public void AddRange(IEnumerable<SitemapUrl> urls)
        {
            _urls.AddRange(urls);
        }

        public static readonly XNamespace Namespace = "http://www.sitemaps.org/schemas/sitemap/0.9";

        public XElement Serialise()
        {
            XElement root = new XElement("urlset");
            root.Add(new XAttribute("xmlns", Namespace));
            root.Add(new XAttribute(XNamespace.Xmlns + "image", SitemapImage.Namespace));

            foreach (SitemapUrl u in _urls)
            {
                root.Add(u.Serialise());
            }

            return root;
        }
    }

    public enum ChangeFrequency 
    {
        Always,
        Hourly,
        Daily,
        Weekly,
        Monthly,
        Yearly,
        Never
    }

    public class SitemapUrl
    {
        private List<SitemapImage> _images = new List<SitemapImage>();

        public IEnumerable<SitemapImage> Images { get { return _images; } }

        public void Add(SitemapImage img)
        {
            _images.Add(img);
        }

        public void AddRange(IEnumerable<SitemapImage> imgs)
        {
            _images.AddRange(imgs);
        }

        public string Location { get; set; }
        public DateTime? LastModified { get; set; }
        public ChangeFrequency? ChangeFrequency { get; set; }
        public Single? Priority { get; set; }

        public XElement Serialise()
        {
            XElement root = new XElement("url");

            root.Add(new XElement("loc", Location));
            
            foreach(SitemapImage img in _images)
            {
                root.Add(img.Serialise());
            }

            if(LastModified.HasValue)
            {
                root.Add(new XElement("lastmod", LastModified.Value.ToString("yyyy-MM-dd")));
            }

            if (ChangeFrequency.HasValue)
            {
                root.Add(new XElement("changefreq", ChangeFrequency.Value.ToString().ToLower()));
            }

            if (Priority.HasValue)
            {
                root.Add(new XElement("priority", Priority.Value.ToString("0.0")));
            }

            return root;
        }
    }

    public class SitemapImage
    {
        public string Location { get; set; }
        public string Caption {get;set;}
        public string GeoLocation {get;set;}
        public string Title {get;set;}
        public string License {get;set;}

        public static readonly XNamespace Namespace = "http://www.google.com/schemas/sitemap-image/1.1";

        public XElement Serialise()
        {
            XElement img = new XElement(Namespace + "image");

            img.Add(new XElement(Namespace + "loc", Location));

            if (!string.IsNullOrWhiteSpace(Caption))
            {
                img.Add(new XElement(Namespace + "caption", Caption));
            }

            if(!string.IsNullOrWhiteSpace(GeoLocation))
            {
                img.Add(new XElement(Namespace + "geo_location", GeoLocation));
            }

            if(!string.IsNullOrWhiteSpace(Title))
            {
                img.Add(new XElement(Namespace + "title", Title));
            }

            if(!string.IsNullOrWhiteSpace(License))
            {
                img.Add(new XElement(Namespace + "license", License));
            }

            return img;
        }
    }

}