﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace Sitecore.TFS.PackageGenerator.Outputs
{
    
    public class SaveXmlToDisk : IOutput
    {
        private ProjectConfiguration _config;

        public void Initialise(ProjectConfiguration config)
        {
            _config = config;
        }

        public void Store(XElement data, string filename)
        {
            var xws = new System.Xml.XmlWriterSettings();
            xws.OmitXmlDeclaration = true;
            xws.Indent = true;

            using (var xw = System.Xml.XmlWriter.Create(filename, xws))
            {
                data.Save(xw);
            }
        }
    }

}