﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Sitecore.TFS.PackageGenerator.PackageModel;

namespace Sitecore.TFS.PackageGenerator.PipelineComponents
{

    public class PipelineData
    {
        public IDictionary<string, SourceControlActions> Input { get; set; }
        public PackageProject Output { get; set; }
        public ProjectConfiguration Configuration { get; set; }
    }

}