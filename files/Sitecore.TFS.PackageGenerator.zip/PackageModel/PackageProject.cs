﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace Sitecore.TFS.PackageGenerator.PackageModel
{
    
    public class PackageProject : IToXml
    {
        public PackageMetadata Metadata { get; private set; }
        public bool SaveProject { get; set; }
        public PackageSources Sources { get; private set; }
        public PackageConverter Converter { get; private set; }

        public PackageProject()
        {
            Metadata = new PackageMetadata();
            SaveProject = true;
            Sources = new PackageSources();
            Converter = new PackageConverter();
        }

        public XElement ToXml()
        {
            XElement xPackage = new XElement("project");

            xPackage.Add(Metadata.ToXml());
            xPackage.Add(new XElement("SaveProject", SaveProject));
            xPackage.Add(Sources.ToXml());
            xPackage.Add(Converter.ToXml());
            xPackage.Add(new XElement("Include"));
            xPackage.Add(new XElement("Exclude"));
            xPackage.Add(new XElement("Name"));

            return xPackage;
        }
    }

}