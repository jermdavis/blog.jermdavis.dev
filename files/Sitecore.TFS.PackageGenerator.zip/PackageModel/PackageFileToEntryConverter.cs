﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace Sitecore.TFS.PackageGenerator.PackageModel
{

    public class PackageFileToEntryConverter : IToXml
    {
        public XElement ToXml()
        {
            return new XElement("Converter",
                new XElement("FileToEntryConverter",
                        new XElement("Root", "/"),
                        new XElement("Transforms")
                    ));
        }
    }

}